package ca.ucalgary.seng300.service;

/*暂无此功能*/
public interface ILoginService {
}
