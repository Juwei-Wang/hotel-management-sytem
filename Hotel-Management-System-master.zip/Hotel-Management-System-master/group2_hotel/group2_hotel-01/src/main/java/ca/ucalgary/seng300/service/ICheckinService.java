package ca.ucalgary.seng300.service;

import org.springframework.stereotype.Service;

@Service
public interface ICheckinService extends IAdminService{
}
