package ca.ucalgary.seng300.service;

public interface IAdminService {


}
